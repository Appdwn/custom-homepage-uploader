<?php
/**
 * Plugin Name: Custom Homepage Uploader
 * Description: Upload an HTML or PHP file to use as the homepage.
 * Version: 1.1
 * Author: Abdellah El Kilani
 * Author URI: https://appdwn.com
 */

add_action('admin_menu', function() {
    add_menu_page(
        'Homepage Uploader',
        'Homepage Uploader',
        'manage_options',
        'custom-homepage-uploader',
        'custom_homepage_uploader_page',
        'dashicons-upload',
        81
    );
});

function custom_homepage_uploader_page() {
    if (!current_user_can('manage_options')) return;

    $upload_dir = wp_upload_dir()['basedir'] . '/custom-home';
    $uploaded_url = wp_upload_dir()['baseurl'] . '/custom-home';

    if (!file_exists($upload_dir)) {
        wp_mkdir_p($upload_dir);
    }

    if (isset($_FILES['custom_home_file']) && $_FILES['custom_home_file']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['custom_home_file']['tmp_name'];
        $file_name = basename($_FILES['custom_home_file']['name']);
        $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);

        if (in_array($file_ext, ['html', 'php'])) {
            move_uploaded_file($file_tmp, "$upload_dir/index.$file_ext");
            echo '<div class="notice notice-success is-dismissible"><p><strong>File uploaded successfully!</strong></p></div>';
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>Only .html or .php files are allowed.</p></div>';
        }
    }

    echo '<div class="wrap" style="font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, \'Helvetica Neue\', Arial, sans-serif;">';
    echo '<div style="background: #f9f9f9; padding: 30px; border-radius: 8px; border: 1px solid #ddd; max-width: 700px; box-shadow: 0 0 10px rgba(0,0,0,0.05);">';
    echo '<h1 style="display: flex; align-items: center; gap: 10px;"><span class="dashicons dashicons-upload"></span> Custom Homepage Uploader</h1>';
    echo '<p style="font-size: 15px; color: #333;">Easily upload an <code>index.html</code> or <code>index.php</code> file to replace your current WordPress homepage with a custom design.</p>';
    echo '<form method="POST" enctype="multipart/form-data" style="margin-top: 20px;">';
    echo '<label for="custom_home_file" style="font-weight: 600; display: block; margin-bottom: 8px;">Select a homepage file (.html or .php):</label>';
    echo '<input type="file" name="custom_home_file" accept=".html,.php" required style="margin-bottom: 20px; padding: 6px; width: 100%; max-width: 100%;" /><br>';
    echo '<input type="submit" class="button button-primary" value="Upload & Replace Homepage" style="font-size: 15px; padding: 8px 20px;" />';
    echo '</form>';
    echo '<hr style="margin: 30px 0;">';
    echo '<div style="text-align: center; font-size: 13px; color: #777;">';
    echo 'Plugin developed by <a href="https://appdwn.com" target="_blank" style="color: #2271b1; text-decoration: none;">Abdellah El Kilani</a>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
}

add_action('template_redirect', function() {
    if (is_front_page()) {
        $upload_dir = wp_upload_dir()['basedir'] . '/custom-home';

        if (file_exists("$upload_dir/index.php")) {
            include("$upload_dir/index.php");
            exit;
        } elseif (file_exists("$upload_dir/index.html")) {
            echo file_get_contents("$upload_dir/index.html");
            exit;
        }
    }
});
